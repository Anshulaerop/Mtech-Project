# Reserve — Event Booking & Scheduling System

A full-stack booking system where users browse events, pick a time slot, and reserve
a place. The defining feature is **conflict-free reservation**: many people can try to
book the same slot at the same instant, and the system fills exactly the available
seats — never one more — then emails each attendee a confirmation.

> **Resume hook:** *Booking system with conflict-free slot reservation and email confirmations.*

Built with Node.js + Express + SQLite (`better-sqlite3`) on the back end and a
dependency-free vanilla-JS single-page front end. No build step, no external database
server, no cloud services required to run.

---

## Quick start

Requires **Node.js 18 or newer** (it uses the built-in `fetch`).

```bash
npm install        # install dependencies
npm run seed       # create the database and load sample events
npm start          # start the server
```

Then open **http://localhost:3000**.

To prove the concurrency claim, open a second terminal while the server is running:

```bash
npm run test:concurrency
```

You'll see something like:

```
Slot #1  capacity=6  seats_left=6
Firing 25 simultaneous booking requests...

Confirmed (201):        6
Rejected as full (409): 19
Final booked_count:     6 / 6

PASS — exactly 6 seat(s) filled, 19 correctly turned away, zero overbooking.
```

Useful extra commands:

```bash
npm run reset      # wipe all bookings and reseed fresh sample data
```

---

## How double-booking is prevented

This is the part worth talking about in an interview. Overbooking is prevented in
three independent layers, so the system is correct even if one layer were removed
(all in `db.js`):

1. **`BEGIN IMMEDIATE` transaction.** Each booking runs inside an *immediate*
   transaction, which acquires SQLite's single writer lock at the very start. Two
   bookings for the same slot therefore cannot interleave the
   *read-seats → check → insert* sequence. The second one waits for the first to
   commit and then sees the updated count. This closes the classic race condition
   where two requests both read "1 seat left" and both insert.

2. **`UNIQUE(slot_id, email)` constraint.** The same person clicking *Book* twice in
   quick succession can't create two bookings for one slot — the second insert is
   rejected and surfaced as a friendly "you already have a booking" message.

3. **`CHECK (booked_count <= capacity)` constraint.** A final backstop enforced by the
   database itself: any update that would push a slot past its capacity is refused, so
   overbooking is structurally impossible even if the application logic had a bug.

`better-sqlite3` is synchronous, and combined with `busy_timeout` the competing writers
queue rather than error out under load. The `test-concurrency.js` script exercises all
of this by firing many real HTTP requests simultaneously.

---

## Project structure

```
event-booking-system/
├── server.js            Express app entry point
├── db.js                schema, queries, and the concurrency-safe bookSlot()
├── email.js             confirmation email sender (log / ethereal / smtp modes)
├── seed.js              sample events and time slots
├── test-concurrency.js  fires N simultaneous bookings to prove no overbooking
├── routes/
│   ├── events.js        GET /api/events, GET /api/events/:id
│   └── bookings.js      POST /api/bookings, GET /api/bookings/:reference
└── public/              the single-page front end (HTML, CSS, JS)
```

---

## API

| Method | Route                     | Purpose                                   |
| ------ | ------------------------- | ----------------------------------------- |
| GET    | `/api/events`             | List events with a seats-left summary     |
| GET    | `/api/events/:id`         | One event with all its time slots         |
| POST   | `/api/bookings`           | Reserve a seat — body `{ slotId, name, email }` |
| GET    | `/api/bookings/:reference`| Look up a booking by its reference code   |

`POST /api/bookings` returns **201** on success, **409** when the slot is full or the
person already booked it, and **400** for invalid input.

---

## Email confirmations

Controlled by `EMAIL_MODE` (see `.env.example`). No configuration is needed to run:

- **`log`** (default) — writes each confirmation to `sent-emails/<reference>.html`.
  Open the file in a browser to see the rendered email. Works fully offline.
- **`ethereal`** — sends through a throwaway [Ethereal](https://ethereal.email) inbox
  and prints a preview URL in the server log. Needs internet, no signup.
- **`smtp`** — sends through a real SMTP server using the `SMTP_*` variables. Use this
  with Gmail, SendGrid, Mailtrap, etc. for real delivery.

To configure, copy `.env.example` to `.env` and edit.

Sending is best-effort by design: the booking is committed to the database first, so a
mail failure never costs someone their seat.

---

## Tech notes

- **No ORM.** Queries are prepared statements, which keeps the concurrency behaviour
  explicit and easy to reason about.
- **No front-end framework.** The SPA is plain ES modules and `fetch`, so it runs as-is
  from the `public/` folder with zero tooling.
- **Timestamps** are stored as ISO 8601 strings and rendered in the browser's locale.

## Possible extensions

- Cancellation (free the seat, decrement the count in the same transaction pattern).
- Waitlists that auto-promote when a seat frees up.
- Admin view to create events and slots from the UI.
- Rate limiting on `POST /api/bookings` to blunt abusive clients.

## License

MIT.
