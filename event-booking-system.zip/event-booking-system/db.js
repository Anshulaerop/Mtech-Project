'use strict';

/**
 * Database layer.
 *
 * Uses better-sqlite3 (synchronous, transaction-friendly) so the whole
 * project runs with zero external services — the database is a single file
 * (data.db) created on first run.
 *
 * The important part of this file is `bookSlot`, which is where double-booking
 * is prevented. See the long comment above it.
 */

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data.db');
const db = new Database(DB_PATH);

// --- Pragmas that make concurrent access correct and non-blocking ----------
// WAL lets readers and a writer coexist without blocking each other.
db.pragma('journal_mode = WAL');
// If a competing writer holds the lock, wait up to 5s instead of erroring.
db.pragma('busy_timeout = 5000');
// Enforce foreign keys (off by default in SQLite).
db.pragma('foreign_keys = ON');

// --- Schema ----------------------------------------------------------------
db.exec(`
  CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    description TEXT,
    location    TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS slots (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id     INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    starts_at    TEXT NOT NULL,          -- ISO 8601 timestamp
    ends_at      TEXT NOT NULL,          -- ISO 8601 timestamp
    capacity     INTEGER NOT NULL DEFAULT 1 CHECK (capacity > 0),
    booked_count INTEGER NOT NULL DEFAULT 0 CHECK (booked_count >= 0),
    CHECK (booked_count <= capacity)     -- DB refuses to ever overbook
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    slot_id    INTEGER NOT NULL REFERENCES slots(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL,
    reference  TEXT NOT NULL UNIQUE,     -- human-facing confirmation code
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (slot_id, email)              -- same person can't book a slot twice
  );

  CREATE INDEX IF NOT EXISTS idx_slots_event ON slots(event_id);
  CREATE INDEX IF NOT EXISTS idx_bookings_slot ON bookings(slot_id);
`);

// --- Read queries ----------------------------------------------------------

const listEventsStmt = db.prepare(`
  SELECT
    e.id, e.title, e.description, e.location,
    COUNT(s.id)                              AS slot_count,
    COALESCE(SUM(s.capacity - s.booked_count), 0) AS seats_left
  FROM events e
  LEFT JOIN slots s ON s.event_id = e.id
  GROUP BY e.id
  ORDER BY e.id
`);

const getEventStmt = db.prepare(`SELECT * FROM events WHERE id = ?`);

const getSlotsForEventStmt = db.prepare(`
  SELECT
    id, event_id, starts_at, ends_at, capacity, booked_count,
    (capacity - booked_count) AS seats_left
  FROM slots
  WHERE event_id = ?
  ORDER BY starts_at
`);

const getBookingByRefStmt = db.prepare(`
  SELECT
    b.reference, b.name, b.email, b.created_at,
    s.starts_at, s.ends_at,
    e.title AS event_title, e.location
  FROM bookings b
  JOIN slots s  ON s.id = b.slot_id
  JOIN events e ON e.id = s.event_id
  WHERE b.reference = ?
`);

function listEvents() {
  return listEventsStmt.all();
}

function getEventWithSlots(eventId) {
  const event = getEventStmt.get(eventId);
  if (!event) return null;
  event.slots = getSlotsForEventStmt.all(eventId);
  return event;
}

function getBookingByReference(reference) {
  return getBookingByRefStmt.get(reference);
}

// --- The concurrency-safe booking transaction -----------------------------
//
// Why this is safe against double-booking, in three layers:
//
//   1. IMMEDIATE transaction. better-sqlite3's `.immediate` variant issues
//      `BEGIN IMMEDIATE`, which grabs SQLite's single write lock at the very
//      start. Two bookings for the same slot therefore cannot interleave the
//      read-check-then-write sequence — the second one waits (up to
//      busy_timeout) for the first to COMMIT, then sees the updated count.
//      This closes the classic race: "both read seats_left = 1, both insert".
//
//   2. UNIQUE(slot_id, email). Even if the same person clicks "Book" twice in
//      parallel, the second INSERT fails with a UNIQUE constraint error, which
//      we surface as a friendly "already booked" message.
//
//   3. CHECK (booked_count <= capacity) on the slots table. A final backstop:
//      the database itself will reject any UPDATE that would push a slot past
//      its capacity, so overbooking is impossible even if application logic
//      were wrong.
//
// The function throws Error objects with a `.code` we translate to HTTP status
// codes in the route handler.

const findSlotStmt = db.prepare(
  `SELECT id, capacity, booked_count FROM slots WHERE id = ?`
);
const insertBookingStmt = db.prepare(
  `INSERT INTO bookings (slot_id, name, email, reference) VALUES (?, ?, ?, ?)`
);
const incrementSlotStmt = db.prepare(
  `UPDATE slots SET booked_count = booked_count + 1 WHERE id = ?`
);

const bookSlotTxn = db.transaction((slotId, name, email, reference) => {
  const slot = findSlotStmt.get(slotId);
  if (!slot) {
    throw Object.assign(new Error('That time slot does not exist.'), {
      code: 'NOT_FOUND',
    });
  }
  if (slot.booked_count >= slot.capacity) {
    throw Object.assign(new Error('That time slot is fully booked.'), {
      code: 'FULL',
    });
  }

  try {
    insertBookingStmt.run(slotId, name, email, reference);
  } catch (err) {
    if (String(err.code).startsWith('SQLITE_CONSTRAINT')) {
      throw Object.assign(
        new Error('You already have a booking for this time slot.'),
        { code: 'DUPLICATE' }
      );
    }
    throw err;
  }

  incrementSlotStmt.run(slotId);
  return getBookingByRefStmt.get(reference);
});

/**
 * Reserve one seat in a slot. Runs as an IMMEDIATE (write-locked) transaction.
 * @returns the created booking joined with slot/event details
 * @throws Error with .code of NOT_FOUND | FULL | DUPLICATE
 */
function bookSlot(slotId, name, email, reference) {
  // `.immediate(...)` runs the transaction with BEGIN IMMEDIATE — see note above.
  return bookSlotTxn.immediate(slotId, name, email, reference);
}

module.exports = {
  db,
  listEvents,
  getEventWithSlots,
  getBookingByReference,
  bookSlot,
};
