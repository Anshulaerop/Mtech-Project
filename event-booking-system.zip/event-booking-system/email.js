'use strict';

/**
 * Confirmation email sender.
 *
 * Three modes, chosen with EMAIL_MODE:
 *   - "log"      (default) renders the email to an .html file in ./sent-emails
 *                and logs the path. Works fully offline, zero config.
 *   - "ethereal" uses a throwaway Ethereal inbox and logs a preview URL.
 *                Requires internet, no account needed.
 *   - "smtp"     uses a real SMTP server from the SMTP_* env vars.
 *
 * Sending is best-effort: a failed email never fails the booking. The booking
 * is already committed by the time we get here; the email is a notification.
 */

const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');

const MODE = (process.env.EMAIL_MODE || 'log').toLowerCase();
const SENT_DIR = path.join(__dirname, 'sent-emails');
const FROM = process.env.EMAIL_FROM || 'Bookings <no-reply@bookings.local>';

let transporterPromise = null;

async function getTransporter() {
  if (transporterPromise) return transporterPromise;

  transporterPromise = (async () => {
    if (MODE === 'smtp') {
      return nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });
    }
    if (MODE === 'ethereal') {
      const account = await nodemailer.createTestAccount();
      return nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false,
        auth: { user: account.user, pass: account.pass },
      });
    }
    return null; // "log" mode has no transporter
  })();

  return transporterPromise;
}

function formatWhen(startsAt, endsAt) {
  const opts = {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  };
  const start = new Date(startsAt).toLocaleString('en-GB', opts);
  const end = new Date(endsAt).toLocaleString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
  });
  return `${start} – ${end}`;
}

function renderHtml(booking) {
  const when = formatWhen(booking.starts_at, booking.ends_at);
  return `<!doctype html>
<html>
  <body style="margin:0;background:#eef1f6;font-family:Arial,Helvetica,sans-serif;color:#141b2e;">
    <div style="max-width:520px;margin:32px auto;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #dfe4ee;">
      <div style="background:#141b2e;color:#fff;padding:24px 28px;">
        <div style="font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:#9fb0d0;">Booking confirmed</div>
        <div style="font-size:22px;font-weight:700;margin-top:6px;">${booking.event_title}</div>
      </div>
      <div style="padding:24px 28px;">
        <p style="margin:0 0 16px;">Hi ${booking.name}, your place is reserved.</p>
        <table style="width:100%;border-collapse:collapse;font-size:15px;">
          <tr>
            <td style="padding:8px 0;color:#5b6577;width:120px;">When</td>
            <td style="padding:8px 0;font-weight:600;">${when}</td>
          </tr>
          <tr>
            <td style="padding:8px 0;color:#5b6577;">Where</td>
            <td style="padding:8px 0;font-weight:600;">${booking.location || 'TBC'}</td>
          </tr>
          <tr>
            <td style="padding:8px 0;color:#5b6577;">Reference</td>
            <td style="padding:8px 0;">
              <span style="font-family:'Courier New',monospace;font-weight:700;letter-spacing:.08em;background:#eef1f6;padding:4px 10px;border-radius:6px;">${booking.reference}</span>
            </td>
          </tr>
        </table>
        <p style="margin:20px 0 0;font-size:13px;color:#5b6577;">Keep this reference handy — you'll need it if you want to look up or cancel your booking.</p>
      </div>
    </div>
  </body>
</html>`;
}

/**
 * Send a confirmation email. Never throws — returns a small result object
 * describing what happened, which the caller may log.
 */
async function sendConfirmation(booking) {
  const html = renderHtml(booking);
  const subject = `Booking confirmed — ${booking.event_title} [${booking.reference}]`;

  try {
    if (MODE === 'log') {
      if (!fs.existsSync(SENT_DIR)) fs.mkdirSync(SENT_DIR, { recursive: true });
      const file = path.join(SENT_DIR, `${booking.reference}.html`);
      fs.writeFileSync(file, html);
      console.log(`  ✉  [log] confirmation written to ${path.relative(process.cwd(), file)}`);
      return { ok: true, mode: 'log', file };
    }

    const transporter = await getTransporter();
    const info = await transporter.sendMail({
      from: FROM,
      to: booking.email,
      subject,
      html,
    });

    if (MODE === 'ethereal') {
      const preview = nodemailer.getTestMessageUrl(info);
      console.log(`  ✉  [ethereal] preview: ${preview}`);
      return { ok: true, mode: 'ethereal', preview };
    }

    console.log(`  ✉  [smtp] sent to ${booking.email} (id ${info.messageId})`);
    return { ok: true, mode: 'smtp', messageId: info.messageId };
  } catch (err) {
    // Best-effort: log and move on. The booking is already saved.
    console.warn(`  ✉  email failed (${err.message}) — booking still confirmed`);
    return { ok: false, error: err.message };
  }
}

module.exports = { sendConfirmation };
