'use strict';

const app = document.getElementById('app');

// ---------- helpers ----------
async function api(path, options) {
  const res = await fetch(path, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function fmtDate(iso) {
  return new Date(iso).toLocaleDateString('en-GB', {
    weekday: 'short', day: 'numeric', month: 'short',
  });
}
function fmtTime(iso) {
  return new Date(iso).toLocaleTimeString('en-GB', {
    hour: '2-digit', minute: '2-digit',
  });
}

// Availability class from seats left / capacity
function availClass(left, capacity) {
  if (left <= 0) return 'none';
  if (left <= Math.max(1, Math.ceil(capacity * 0.25))) return 'low';
  return 'go';
}

// ---------- Views ----------
async function renderEvents() {
  app.innerHTML = `<div class="state">Loading events…</div>`;
  let events;
  try {
    events = await api('/api/events');
  } catch (e) {
    app.innerHTML = `<div class="state">Couldn't load events. Is the server running?</div>`;
    return;
  }

  const cards = events.map((ev) => {
    const cls = availClass(ev.seats_left, ev.seats_left + 1);
    const pill =
      ev.seats_left <= 0
        ? `<span class="pill pill--none">Full</span>`
        : `<span class="pill pill--${cls === 'go' ? 'go' : 'low'}">${ev.seats_left} left</span>`;
    return `
      <button class="event-card" data-event="${ev.id}">
        <h3 class="event-card__title">${esc(ev.title)}</h3>
        <div class="event-card__loc">${esc(ev.location || '')}</div>
        <div class="event-card__meta">
          <span class="event-card__slots">${ev.slot_count} time slot${ev.slot_count === 1 ? '' : 's'}</span>
          ${pill}
        </div>
      </button>`;
  }).join('');

  app.innerHTML = `
    <p class="eyebrow">Open for booking</p>
    <h1 class="page-title">Reserve your place</h1>
    <p class="page-sub">Browse upcoming sessions and lock in a time. Each slot has limited capacity — once it's full, it's full.</p>
    <div class="event-grid">${cards}</div>
  `;

  app.querySelectorAll('[data-event]').forEach((el) =>
    el.addEventListener('click', () => renderEvent(Number(el.dataset.event)))
  );
}

async function renderEvent(eventId) {
  app.innerHTML = `<div class="state">Loading…</div>`;
  let ev;
  try {
    ev = await api(`/api/events/${eventId}`);
  } catch (e) {
    app.innerHTML = `<div class="state">${esc(e.message)}</div>`;
    return;
  }

  const slots = ev.slots.map((s) => {
    const cls = availClass(s.seats_left, s.capacity);
    const pct = Math.round((s.booked_count / s.capacity) * 100);
    const label =
      s.seats_left <= 0
        ? 'Fully booked'
        : `${s.seats_left} of ${s.capacity} seat${s.capacity === 1 ? '' : 's'} left`;
    const action =
      s.seats_left <= 0
        ? `<button class="btn btn--full" disabled>Full</button>`
        : `<button class="btn btn--primary" data-slot="${s.id}">Book</button>`;
    return `
      <div class="slot">
        <div>
          <div class="slot__time">${fmtTime(s.starts_at)} – ${fmtTime(s.ends_at)}</div>
          <div class="slot__date">${fmtDate(s.starts_at)}</div>
        </div>
        <div class="slot__book">${action}</div>
        <div class="meter">
          <div class="meter__track">
            <div class="meter__fill meter__fill--${cls}" style="width:${pct}%"></div>
          </div>
          <div class="meter__label">${label}</div>
        </div>
      </div>`;
  }).join('');

  app.innerHTML = `
    <button class="back" data-nav="events">← All events</button>
    <p class="eyebrow">${esc(ev.location || 'Event')}</p>
    <h1 class="page-title">${esc(ev.title)}</h1>
    <p class="page-sub">${esc(ev.description || '')}</p>
    <div class="slot-list">${slots}</div>
  `;

  app.querySelector('[data-nav="events"]').addEventListener('click', renderEvents);
  app.querySelectorAll('[data-slot]').forEach((el) =>
    el.addEventListener('click', () =>
      renderBookingForm(ev, ev.slots.find((s) => s.id === Number(el.dataset.slot)))
    )
  );
}

function renderBookingForm(ev, slot) {
  app.innerHTML = `
    <button class="back" data-back>← Back to ${esc(ev.title)}</button>
    <p class="eyebrow">Booking</p>
    <h1 class="page-title">Reserve this slot</h1>
    <div class="book-panel">
      <div class="book-panel__slot">
        ${esc(ev.title)}<br />
        ${fmtDate(slot.starts_at)} · ${fmtTime(slot.starts_at)} – ${fmtTime(slot.ends_at)}
      </div>
      <div class="field">
        <label for="nameInput">Your name</label>
        <input id="nameInput" type="text" autocomplete="name" placeholder="Ada Lovelace" />
      </div>
      <div class="field">
        <label for="emailInput">Email</label>
        <input id="emailInput" type="email" autocomplete="email" placeholder="ada@example.com" />
      </div>
      <div class="form-error" id="formError"></div>
      <div class="form-actions">
        <button class="btn btn--ghost" data-back>Cancel</button>
        <button class="btn btn--primary" id="confirmBtn">Confirm booking</button>
      </div>
    </div>
  `;

  const back = () => renderEvent(ev.id);
  app.querySelectorAll('[data-back]').forEach((el) => el.addEventListener('click', back));

  const nameInput = document.getElementById('nameInput');
  const emailInput = document.getElementById('emailInput');
  const errorEl = document.getElementById('formError');
  const btn = document.getElementById('confirmBtn');
  nameInput.focus();

  btn.addEventListener('click', async () => {
    errorEl.textContent = '';
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    if (name.length < 2) { errorEl.textContent = 'Please enter your name.'; return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errorEl.textContent = 'Please enter a valid email address.'; return;
    }

    btn.disabled = true;
    btn.textContent = 'Reserving…';
    try {
      const result = await api('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotId: slot.id, name, email }),
      });
      renderConfirmation(result);
    } catch (e) {
      if (e.status === 409) {
        // Someone took the last seat, or duplicate. Show message + offer to go back.
        errorEl.textContent = e.message;
      } else {
        errorEl.textContent = e.message;
      }
      btn.disabled = false;
      btn.textContent = 'Confirm booking';
    }
  });
}

function renderConfirmation(result) {
  const emailLine = result.emailPreview
    ? `A preview of your confirmation email is <a href="${esc(result.emailPreview)}" target="_blank" rel="noopener">available here</a>.`
    : result.emailDelivered
    ? `A confirmation email is on its way to ${esc(result.email)}.`
    : `We couldn't send the confirmation email, but your booking is secured — keep your reference.`;

  app.innerHTML = `
    <div class="confirm">
      <div class="confirm__check">✓</div>
      <h2>You're booked in</h2>
      <p class="muted">Save your reference below.</p>
      <div class="confirm__ref">${esc(result.reference)}</div>
      <div class="confirm__details">
        <div class="confirm__row"><span>Event</span><span>${esc(result.event)}</span></div>
        <div class="confirm__row"><span>When</span><span>${fmtDate(result.startsAt)} · ${fmtTime(result.startsAt)}–${fmtTime(result.endsAt)}</span></div>
        <div class="confirm__row"><span>Where</span><span>${esc(result.location || 'TBC')}</span></div>
      </div>
      <p class="confirm__note">${emailLine}</p>
      <div class="form-actions" style="justify-content:center;margin-top:20px;">
        <button class="btn btn--ghost" data-nav="events">Back to events</button>
      </div>
    </div>
  `;
  app.querySelector('[data-nav="events"]').addEventListener('click', renderEvents);
}

// ---------- Lookup modal ----------
const lookupModal = document.getElementById('lookupModal');
const lookupResult = document.getElementById('lookupResult');
const refInput = document.getElementById('refInput');

function openLookup() {
  lookupResult.innerHTML = '';
  refInput.value = '';
  lookupModal.hidden = false;
  refInput.focus();
}
function closeLookup() {
  lookupModal.hidden = true;
}

document.getElementById('lookupBtn').addEventListener('click', openLookup);
document.querySelectorAll('[data-close-lookup]').forEach((el) =>
  el.addEventListener('click', closeLookup)
);
lookupModal.addEventListener('click', (e) => {
  if (e.target === lookupModal) closeLookup();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !lookupModal.hidden) closeLookup();
});

document.getElementById('lookupSubmit').addEventListener('click', async () => {
  const ref = refInput.value.trim().toUpperCase();
  if (!ref) return;
  lookupResult.innerHTML = `<span class="muted">Looking…</span>`;
  try {
    const b = await api(`/api/bookings/${encodeURIComponent(ref)}`);
    lookupResult.innerHTML = `
      <div class="ok">
        <div><strong>${esc(b.reference)}</strong></div>
        <div style="margin-top:6px;">${esc(b.event_title)}</div>
        <div class="muted">${fmtDate(b.starts_at)} · ${fmtTime(b.starts_at)}–${fmtTime(b.ends_at)}</div>
        <div class="muted">${esc(b.location || '')}</div>
        <div class="muted" style="margin-top:6px;">Booked by ${esc(b.name)}</div>
      </div>`;
  } catch (e) {
    lookupResult.innerHTML = `<span class="err">${esc(e.message)}</span>`;
  }
});
refInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('lookupSubmit').click();
});

// Brand click → home
document.querySelector('.brand').addEventListener('click', (e) => {
  e.preventDefault();
  renderEvents();
});

// ---------- boot ----------
renderEvents();
