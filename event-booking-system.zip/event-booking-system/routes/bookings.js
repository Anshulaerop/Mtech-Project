'use strict';

const express = require('express');
const { customAlphabet } = require('nanoid');
const { bookSlot, getBookingByReference } = require('../db');
const { sendConfirmation } = require('../email');

const router = express.Router();

// Human-friendly reference: no ambiguous characters (0/O, 1/I), e.g. "BK-7F3K9Q"
const makeCode = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 6);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const STATUS_FOR_CODE = {
  NOT_FOUND: 404,
  FULL: 409, // Conflict — the honest status for "someone else took the seat"
  DUPLICATE: 409,
};

// POST /api/bookings  — reserve a seat
// body: { slotId, name, email }
router.post('/', async (req, res) => {
  const { slotId, name, email } = req.body || {};

  // --- validation ---
  if (!Number.isInteger(slotId)) {
    return res.status(400).json({ error: 'A valid slotId is required.' });
  }
  if (!name || typeof name !== 'string' || name.trim().length < 2) {
    return res.status(400).json({ error: 'Please enter your name.' });
  }
  if (!email || !EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  const reference = `BK-${makeCode()}`;

  // --- reserve (concurrency-safe, see db.js) ---
  let booking;
  try {
    booking = bookSlot(slotId, name.trim(), email.trim().toLowerCase(), reference);
  } catch (err) {
    const status = STATUS_FOR_CODE[err.code] || 500;
    if (status === 500) console.error('Booking error:', err);
    return res.status(status).json({ error: err.message });
  }

  // --- confirmation email (best-effort, never blocks the response for long) ---
  const emailResult = await sendConfirmation(booking);

  res.status(201).json({
    reference: booking.reference,
    event: booking.event_title,
    location: booking.location,
    startsAt: booking.starts_at,
    endsAt: booking.ends_at,
    email: booking.email,
    emailDelivered: emailResult.ok,
    emailPreview: emailResult.preview || null, // set in ethereal mode
  });
});

// GET /api/bookings/:reference  — look up a booking
router.get('/:reference', (req, res) => {
  const booking = getBookingByReference(req.params.reference);
  if (!booking) {
    return res.status(404).json({ error: 'No booking found with that reference.' });
  }
  res.json(booking);
});

module.exports = router;
