'use strict';

const express = require('express');
const { listEvents, getEventWithSlots } = require('../db');

const router = express.Router();

// GET /api/events  — all events with a seats-left summary
router.get('/', (req, res) => {
  res.json(listEvents());
});

// GET /api/events/:id  — one event and its time slots
router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ error: 'Invalid event id.' });
  }
  const event = getEventWithSlots(id);
  if (!event) {
    return res.status(404).json({ error: 'Event not found.' });
  }
  res.json(event);
});

module.exports = router;
