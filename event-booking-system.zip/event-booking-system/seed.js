'use strict';

/**
 * Seed the database with sample events and time slots.
 *   node seed.js          — seed only if the events table is empty
 *   node seed.js --reset  — wipe all data and reseed
 */

require('dotenv').config();
const { db } = require('./db');

const reset = process.argv.includes('--reset');

if (reset) {
  db.exec('DELETE FROM bookings; DELETE FROM slots; DELETE FROM events;');
  db.exec(
    "DELETE FROM sqlite_sequence WHERE name IN ('events','slots','bookings');"
  );
  console.log('Cleared existing data.');
}

const count = db.prepare('SELECT COUNT(*) AS n FROM events').get().n;
if (count > 0 && !reset) {
  console.log(`Database already has ${count} event(s). Use --reset to reseed.`);
  process.exit(0);
}

// Build slot timestamps relative to "today" so the data always looks current.
function at(dayOffset, hour, minute = 0) {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
}
function plus(iso, minutes) {
  return new Date(new Date(iso).getTime() + minutes * 60000).toISOString();
}

const events = [
  {
    title: 'Pottery Wheel Workshop',
    description:
      'A hands-on introduction to throwing on the wheel. All clay and tools provided; leave with two finished pieces.',
    location: 'Studio A, Riverside Makerspace',
    slots: [
      { start: at(2, 10), mins: 120, capacity: 6 },
      { start: at(2, 14), mins: 120, capacity: 6 },
      { start: at(4, 10), mins: 120, capacity: 6 },
      { start: at(4, 14), mins: 120, capacity: 1 }, // tiny slot — nice for demos
    ],
  },
  {
    title: 'Portfolio Review with a Senior Engineer',
    description:
      'A focused 1:1 review of your CV, GitHub, and one project. Bring specific questions.',
    location: 'Online (link sent on confirmation)',
    slots: [
      { start: at(1, 9, 30), mins: 30, capacity: 1 },
      { start: at(1, 10, 15), mins: 30, capacity: 1 },
      { start: at(1, 11), mins: 30, capacity: 1 },
      { start: at(3, 16), mins: 30, capacity: 1 },
    ],
  },
  {
    title: 'Intro to Beekeeping',
    description:
      'Meet the hives, learn seasonal care, and taste the harvest. Protective suits supplied.',
    location: 'North Meadow Apiary',
    slots: [
      { start: at(5, 8), mins: 90, capacity: 10 },
      { start: at(6, 8), mins: 90, capacity: 10 },
    ],
  },
];

const insertEvent = db.prepare(
  'INSERT INTO events (title, description, location) VALUES (?, ?, ?)'
);
const insertSlot = db.prepare(
  'INSERT INTO slots (event_id, starts_at, ends_at, capacity) VALUES (?, ?, ?, ?)'
);

const seed = db.transaction(() => {
  for (const ev of events) {
    const { lastInsertRowid: eventId } = insertEvent.run(
      ev.title,
      ev.description,
      ev.location
    );
    for (const s of ev.slots) {
      insertSlot.run(eventId, s.start, plus(s.start, s.mins), s.capacity);
    }
  }
});

seed();

const nEvents = db.prepare('SELECT COUNT(*) AS n FROM events').get().n;
const nSlots = db.prepare('SELECT COUNT(*) AS n FROM slots').get().n;
console.log(`Seeded ${nEvents} events and ${nSlots} time slots.`);
