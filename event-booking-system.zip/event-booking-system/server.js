'use strict';

require('dotenv').config();

const path = require('path');
const express = require('express');

const eventsRouter = require('./routes/events');
const bookingsRouter = require('./routes/bookings');

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/events', eventsRouter);
app.use('/api/bookings', bookingsRouter);

// Health check
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Fallback 404 for unknown API routes
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

app.listen(PORT, () => {
  console.log(`\n  Event Booking System running`);
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  Email mode: ${process.env.EMAIL_MODE || 'log'} (confirmations in ./sent-emails)\n`);
});
