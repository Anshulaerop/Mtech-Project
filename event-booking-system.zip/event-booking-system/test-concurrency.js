'use strict';

/**
 * Concurrency test — proves the "conflict-free" claim.
 *
 * Fires N simultaneous booking requests (all different people) at a single
 * slot whose capacity is C. A correct system confirms exactly C of them and
 * rejects the other N-C with a 409, and the slot's booked_count ends at
 * exactly C — never more.
 *
 * Usage:
 *   1. Start the server in one terminal:   npm start
 *   2. Run this in another:                npm run test:concurrency
 *
 * Optional env: BASE_URL (default http://localhost:3000), ATTEMPTS (default 25)
 */

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';
const ATTEMPTS = Number(process.env.ATTEMPTS || 25);

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`GET ${url} -> ${res.status}`);
  return res.json();
}

async function findTargetSlot() {
  const events = await getJSON(`${BASE_URL}/api/events`);
  for (const ev of events) {
    const full = await getJSON(`${BASE_URL}/api/events/${ev.id}`);
    const slot = full.slots.find((s) => s.seats_left > 0);
    if (slot) return { event: full, slot };
  }
  throw new Error('No slot with availability found. Run `npm run reset` first.');
}

async function attemptBooking(slotId, i) {
  const res = await fetch(`${BASE_URL}/api/bookings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      slotId,
      name: `Tester ${i}`,
      email: `tester${i}@example.com`,
    }),
  });
  const body = await res.json().catch(() => ({}));
  return { status: res.status, body };
}

(async () => {
  console.log(`\nConcurrency test against ${BASE_URL}`);

  const { event, slot } = await findTargetSlot();
  const capacity = slot.capacity;
  const seatsLeft = slot.seats_left;

  console.log(`Target: "${event.title}"`);
  console.log(`Slot #${slot.id}  capacity=${capacity}  seats_left=${seatsLeft}`);
  console.log(`Firing ${ATTEMPTS} simultaneous booking requests...\n`);

  // Launch all requests at once — this is the actual race.
  const results = await Promise.all(
    Array.from({ length: ATTEMPTS }, (_, i) => attemptBooking(slot.id, i))
  );

  const confirmed = results.filter((r) => r.status === 201);
  const rejected = results.filter((r) => r.status === 409);
  const other = results.filter((r) => r.status !== 201 && r.status !== 409);

  // Re-read the slot to confirm booked_count never exceeded capacity.
  const after = await getJSON(`${BASE_URL}/api/events/${event.id}`);
  const finalSlot = after.slots.find((s) => s.id === slot.id);

  console.log(`Confirmed (201):        ${confirmed.length}`);
  console.log(`Rejected as full (409): ${rejected.length}`);
  if (other.length) console.log(`Other statuses:         ${other.length}`);
  console.log(
    `Final booked_count:     ${finalSlot.booked_count} / ${finalSlot.capacity}\n`
  );

  const pass =
    confirmed.length === seatsLeft &&
    finalSlot.booked_count === finalSlot.capacity &&
    finalSlot.booked_count <= finalSlot.capacity &&
    other.length === 0;

  if (pass) {
    console.log(
      `PASS — exactly ${seatsLeft} seat(s) filled, ${rejected.length} correctly turned away, zero overbooking.`
    );
    process.exit(0);
  } else {
    console.log('FAIL — see counts above.');
    process.exit(1);
  }
})().catch((err) => {
  console.error('\nTest error:', err.message);
  console.error('Is the server running? Start it with `npm start`.');
  process.exit(1);
});
